PHONEPE PAYMENT GATEWAY FOR SHOFY / BOTBLE CMS 7.5+
Version 1.0.5

IMPORTANT
This plugin uses PhonePe Standard Checkout v2 (hosted checkout). It requires a PhonePe PG account enabled for the selected environment. It has not been run against your private production merchant credentials or your live Shofy server; run the checklist below before enabling live payments.

INSTALL USING CPANEL
1. Back up your website files and database.
2. Extract this ZIP on your computer. The ZIP contains a top-level `phonepe` folder.
3. Upload the `phonepe` folder to:
   public_html/yourdomain.com/platform/plugins/
   The resulting path should be:
   public_html/yourdomain.com/platform/plugins/phonepe/plugin.json
4. In Botble Admin, open Plugins and activate PhonePe Payment Gateway. If PhonePe is not listed, verify the folder structure and plugin.json path.
5. Open Settings > Payment > PhonePe.
6. Enter the PhonePe PG Client ID, Client Secret and Client Version from the same merchant account/environment.
7. Choose Sandbox / UAT first, save, and test with credentials and test instruments provided by PhonePe. Switch to Production only after PhonePe has enabled live API access.
8. Enable the PhonePe payment method and ensure the store currency is INR.
9. Clear the Botble/Laravel application cache if the admin settings or plugin list does not update.

API ENDPOINTS
Sandbox token: https://api-preprod.phonepe.com/apis/pg-sandbox/v1/oauth/token
Sandbox API:   https://api-preprod.phonepe.com/apis/pg-sandbox
Production token: https://api.phonepe.com/apis/identity-manager/v1/oauth/token
Production API:   https://api.phonepe.com/apis/pg
Create checkout: /checkout/v2/pay
Order status:    /checkout/v2/order/{merchantOrderId}/status

SECURITY / PAYMENT HANDLING
- OAuth credentials are sent server-to-server over HTTPS; never place them in front-end JavaScript.
- The token cache key is derived from environment and credential values; the secret itself is not logged.
- Checkout amounts are converted from INR to paise and checked against the server-verified PhonePe status amount.
- The browser return URL is not trusted by itself. The plugin calls PhonePe's order status API and only marks a payment completed when PhonePe reports COMPLETED and the amount/order ID match.
- Duplicate returns are guarded using a cache lock and processed marker. Use a persistent shared cache store in production, not the array cache driver.
- Cache stores checkout reconciliation metadata for up to six hours. The callback must occur while that data is available.

TEST CHECKLIST
[ ] Plugin appears in Botble Admin and can be activated.
[ ] PhonePe settings save and survive page refresh.
[ ] PhonePe appears at checkout when enabled.
[ ] INR checkout creates a PhonePe hosted checkout URL.
[ ] Successful payment returns to the website and creates one completed payment record.
[ ] Failed/cancelled payment is not marked completed.
[ ] Reloading the callback does not create duplicate payment records.
[ ] A mismatched amount or order ID is not marked completed.
[ ] Production test is performed only after PhonePe confirms live API access.

TROUBLESHOOTING
- HTTP 401/4xx at token endpoint: verify Client ID, Client Secret, Client Version and environment pairing.
- HTTP 500 at token endpoint: this is an upstream PhonePe server response. Check the latest Laravel log for endpoint/status/body, then contact PhonePe PG support with the timestamp and sanitized error response. Do not send your Client Secret.
- If checkout returns an error, inspect storage/logs/laravel.log. The plugin logs endpoint, status, safe response metadata, API code/message, and redirect hostname when a response is rejected; it does not log the full response body, credentials, or access tokens.
- If callback says payment could not be verified, check outbound HTTPS connectivity, cache persistence and the order-status API response.

SUPPORT REFERENCES
PhonePe developer portal: https://developer.phonepe.com/
PhonePe PG developer support: pg-developer@phonepe.com


Security hardening in 1.0.3
- Uses a random, short-lived callback state instead of exposing the Botble checkout token in the PhonePe callback URL.
- Validates callback order ID format and requires the exact merchantOrderId returned by PhonePe order-status verification.
- Restricts hosted checkout redirects to HTTPS subdomains of phonepe.com and phonepe.in. The response validator accepts the documented root redirectUrl field and common nested response shapes, but never redirects to non-PhonePe domains.
- Reduces API error logging to metadata and avoids recording raw response bodies that could contain sensitive information.
- Keeps payment completion dependent on server-to-server order-status verification and exact amount matching.

Deployment notes
- Back up the current plugin folder and site database before upgrading.
- Confirm PHP syntax and test sandbox payments on a staging site before production rollout.
- Keep Client Secret private, use HTTPS on the store, restrict access to Laravel logs, and rotate credentials if they may have been exposed.
- This package has been statically checked; it has not been live-tested against the merchant's PhonePe account or production server.


Version 1.0.4 troubleshooting update
- Adds safe diagnostics for HTTP 200 responses that do not contain an accepted PhonePe checkout URL.
- Supports PhonePe-owned HTTPS checkout subdomains under phonepe.com and phonepe.in while rejecting lookalike domains.
- Accepts root or nested redirectUrl/redirect_url fields, then validates the host before redirecting.


Version 1.0.5 webhook support
- Adds a POST webhook endpoint at: https://yourdomain.com/payment/phonepe/webhook
- Configure the same webhook username and password in Settings > Payment > PhonePe and in the PhonePe Business Dashboard webhook configuration (SHA authentication).
- The expected Authorization value is SHA-256(username:password), compared using a constant-time comparison.
- The endpoint uses the `event` field and root `payload.state`, ignores unsupported events, checks the merchant order ID and amount against the cached checkout snapshot, then checks the event, state, merchant order ID and amount against the server-side checkout snapshot before marking payment complete. The browser return callback separately verifies order status directly with PhonePe.
- Duplicate callback/webhook processing uses the same cache lock and processed marker.
- The webhook route excludes CSRF middleware because PhonePe posts server-to-server. Do not remove the Authorization verification.
- In PhonePe Dashboard > Developer Settings > Webhook, create a webhook for the matching environment, set the URL above, select `checkout.order.completed` and `checkout.order.failed`, choose SHA authentication, and enter the same username/password configured in Botble. Use HTTPS.
- Test webhook delivery using PhonePe's dashboard/test facility and verify Laravel logs before enabling live notifications. Webhook reconciliation data is cached for up to six hours; use a persistent shared cache store in production.
- This implementation currently handles checkout completion/failure notifications only. It does not automatically process refund events.
