<?php

if (! defined('PHONEPE_PAYMENT_METHOD_NAME')) {
    define('PHONEPE_PAYMENT_METHOD_NAME', 'phonepe');
}
