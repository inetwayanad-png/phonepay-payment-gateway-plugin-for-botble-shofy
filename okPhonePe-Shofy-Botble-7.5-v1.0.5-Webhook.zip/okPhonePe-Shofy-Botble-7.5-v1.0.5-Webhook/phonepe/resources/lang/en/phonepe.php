<?php

return [
    'name' => 'PhonePe',
    'description' => 'Pay securely using PhonePe.',
];
