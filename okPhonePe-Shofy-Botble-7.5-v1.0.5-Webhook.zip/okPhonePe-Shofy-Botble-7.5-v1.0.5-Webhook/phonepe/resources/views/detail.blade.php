<div class="mt-3">
    <h6>PhonePe payment details</h6>
    <table class="table table-bordered table-sm">
        <tbody>
        <tr><th>Merchant Order ID</th><td>{{ $payment['merchantOrderId'] ?? $payment['orderId'] ?? '—' }}</td></tr>
        <tr><th>State</th><td>{{ $payment['state'] ?? '—' }}</td></tr>
        <tr><th>Amount (paise)</th><td>{{ isset($payment['amount']) ? number_format(((int) $payment['amount']) / 100, 2) : '—' }}</td></tr>
        </tbody>
    </table>
</div>
