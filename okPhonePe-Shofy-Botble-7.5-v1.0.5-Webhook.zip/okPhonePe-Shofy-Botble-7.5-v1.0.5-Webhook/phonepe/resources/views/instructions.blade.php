<div class="alert alert-info">
    <p><strong>PhonePe Standard Checkout v2</strong></p>
    <ol>
        <li>Obtain Client ID, Client Secret and Client Version from the PhonePe PG merchant dashboard.</li>
        <li>Use Sandbox / UAT credentials with Sandbox mode, or live credentials with Production mode.</li>
        <li>Enable PhonePe after saving the credentials and environment.</li>
        <li>Set the store currency to INR. This plugin rejects non-INR checkout amounts.</li>
    </ol>
    <p>Payments are verified server-to-server using PhonePe's order status API before the order is marked paid.</p>
</div>
