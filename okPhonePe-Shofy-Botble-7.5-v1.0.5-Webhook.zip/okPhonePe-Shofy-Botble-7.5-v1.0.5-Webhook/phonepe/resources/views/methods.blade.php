@if (get_payment_setting('status', PHONEPE_PAYMENT_METHOD_NAME) == 1)
    <x-plugins-payment::payment-method
        :name="PHONEPE_PAYMENT_METHOD_NAME"
        paymentName="PhonePe"
        :supportedCurrencies="['INR']"
    >
        <p>{{ __('Pay securely through PhonePe. You will be redirected to the PhonePe hosted checkout page.') }}</p>
    </x-plugins-payment::payment-method>
@endif
