<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Redirecting to PhonePe</title>
</head>
<body>
    <p>Redirecting you securely to PhonePe…</p>
    <p>If you are not redirected automatically, <a href="{{ $url }}" rel="noopener noreferrer">continue to PhonePe</a>.</p>
    <script>window.location.replace(@json($url));</script>
</body>
</html>
