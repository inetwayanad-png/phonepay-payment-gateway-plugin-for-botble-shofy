<?php

use Botble\PhonePe\Http\Controllers\PhonePeController;
use Botble\Theme\Facades\Theme;
use Illuminate\Support\Facades\Route;

Theme::registerRoutes(function (): void {
    Route::prefix('payment/phonepe')->name('payments.phonepe.')->group(function (): void {
        Route::get('callback', [PhonePeController::class, 'callback'])->name('callback');
    });
}, ['core']);
