<?php

namespace Botble\PhonePe\Forms;

use Botble\Base\Facades\BaseHelper;
use Botble\Base\Forms\FieldOptions\SelectFieldOption;
use Botble\Base\Forms\FieldOptions\TextFieldOption;
use Botble\Base\Forms\Fields\SelectField;
use Botble\Base\Forms\Fields\TextField;
use Botble\Payment\Forms\PaymentMethodForm;

class PhonePePaymentMethodForm extends PaymentMethodForm
{
    public function setup(): void
    {
        parent::setup();

        $this
            ->paymentId(PHONEPE_PAYMENT_METHOD_NAME)
            ->paymentName('PhonePe')
            ->paymentDescription('Pay securely using PhonePe UPI, cards and supported payment methods.')
            ->paymentLogo(url('vendor/core/plugins/phonepe/images/phonepe.svg'))
            ->paymentFeeField(PHONEPE_PAYMENT_METHOD_NAME)
            ->paymentUrl('https://www.phonepe.com/')
            ->paymentInstructions(view('plugins/phonepe::instructions')->render())
            ->add(
                'payment_phonepe_client_id',
                TextField::class,
                TextFieldOption::make()
                    ->label('PhonePe Client ID')
                    ->placeholder('Client ID from PhonePe PG dashboard')
                    ->value(BaseHelper::hasDemoModeEnabled() ? '' : get_payment_setting('client_id', PHONEPE_PAYMENT_METHOD_NAME))
            )
            ->add(
                'payment_phonepe_client_secret',
                'password',
                TextFieldOption::make()
                    ->label('PhonePe Client Secret')
                    ->placeholder('Client Secret from PhonePe PG dashboard')
                    ->value(BaseHelper::hasDemoModeEnabled() ? '' : get_payment_setting('client_secret', PHONEPE_PAYMENT_METHOD_NAME))
            )
            ->add(
                'payment_phonepe_client_version',
                TextField::class,
                TextFieldOption::make()
                    ->label('PhonePe Client Version')
                    ->placeholder('1')
                    ->value(get_payment_setting('client_version', PHONEPE_PAYMENT_METHOD_NAME) ?: '1')
            )
            ->add(
                'payment_phonepe_webhook_username',
                TextField::class,
                TextFieldOption::make()
                    ->label('PhonePe Webhook Username')
                    ->placeholder('Username configured in PhonePe Dashboard')
                    ->value(BaseHelper::hasDemoModeEnabled() ? '' : get_payment_setting('webhook_username', PHONEPE_PAYMENT_METHOD_NAME))
            )
            ->add(
                'payment_phonepe_webhook_password',
                'password',
                TextFieldOption::make()
                    ->label('PhonePe Webhook Password')
                    ->placeholder('Password configured in PhonePe Dashboard')
                    ->value(BaseHelper::hasDemoModeEnabled() ? '' : get_payment_setting('webhook_password', PHONEPE_PAYMENT_METHOD_NAME))
            )
            ->add(
                'payment_phonepe_environment',
                SelectField::class,
                SelectFieldOption::make()
                    ->label('Environment')
                    ->choices([
                        'sandbox' => 'Sandbox / UAT',
                        'production' => 'Production / Live',
                    ])
                    ->selected(strtolower(trim((string) get_payment_setting('environment', PHONEPE_PAYMENT_METHOD_NAME))) === 'production' ? 'production' : 'sandbox')
            );
    }
}
