<?php

namespace Botble\PhonePe\Http\Controllers;

use Botble\Base\Http\Controllers\BaseController;
use Botble\Payment\Enums\PaymentStatusEnum;
use Botble\Payment\Models\Payment;
use Botble\Payment\Supports\PaymentHelper;
use Botble\PhonePe\Services\Gateways\PhonePePaymentService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Throwable;

class PhonePeController extends BaseController
{
    public function callback(Request $request, PhonePePaymentService $service)
    {
        $merchantOrderId = trim((string) $request->query('merchantOrderId', ''));
        $callbackState = trim((string) $request->query('state', ''));
        if ($merchantOrderId === '' || ! preg_match('/^CP[A-Z0-9]{24}$/', $merchantOrderId)
            || $callbackState === '' || strlen($callbackState) > 128) {
            return redirect('/')->with('error_msg', 'PhonePe payment session could not be verified. If you were debited, contact support.');
        }

        $stored = Cache::get('phonepe_order_' . $merchantOrderId);
        if (! is_array($stored)
            || ! isset($stored['callback_state_hash'])
            || ! hash_equals((string) $stored['callback_state_hash'], hash('sha256', $callbackState))
            || empty($stored['checkout_token'])) {
            return redirect('/')->with('error_msg', 'PhonePe payment session could not be verified. If you were debited, contact support.');
        }

        try {
            $status = $service->verifyOrder($merchantOrderId);
            $state = strtoupper((string) ($status['state'] ?? ''));
            $reportedOrderId = (string) ($status['merchantOrderId'] ?? '');
            $reportedAmount = (int) ($status['amount'] ?? -1);

            if (! hash_equals($merchantOrderId, $reportedOrderId)) {
                throw new \RuntimeException('PhonePe returned a different order reference.');
            }

            if ($state === 'COMPLETED' && $reportedAmount === (int) ($stored['amount_paise'] ?? -2)) {
                $this->completeVerifiedPayment($merchantOrderId, $stored);
                return redirect(PaymentHelper::getRedirectURL((string) $stored['checkout_token']) . '?charge_id=' . urlencode($merchantOrderId));
            }

            $checkoutToken = (string) $stored['checkout_token'];
            if (in_array($state, ['FAILED', 'CANCELLED', 'EXPIRED'], true)) {
                return redirect(PaymentHelper::getCancelURL($checkoutToken));
            }

            return redirect(PaymentHelper::getCancelURL($checkoutToken))
                ->with('error_msg', 'PhonePe has not confirmed the payment yet. If you were debited, contact support before retrying.');
        } catch (Throwable $exception) {
            report($exception);
            $checkoutToken = (string) ($stored['checkout_token'] ?? '');
            if ($checkoutToken === '') {
                return redirect('/')->with('error_msg', 'Could not verify the PhonePe payment. If you were debited, contact support before retrying.');
            }
            return redirect(PaymentHelper::getCancelURL($checkoutToken))
                ->with('error_msg', 'Could not verify the PhonePe payment. If you were debited, contact support before retrying.');
        }
    }

    /**
     * PhonePe Standard Checkout server-to-server webhook endpoint.
     * Configure SHA256(username:password) authentication in the PhonePe dashboard.
     */
    public function webhook(Request $request, PhonePePaymentService $service)
    {
        $username = trim((string) get_payment_setting('webhook_username', PHONEPE_PAYMENT_METHOD_NAME));
        $password = (string) get_payment_setting('webhook_password', PHONEPE_PAYMENT_METHOD_NAME);
        $authorization = trim((string) $request->header('Authorization', ''));

        if ($username === '' || $password === '' || $authorization === '') {
            logger()->warning('PhonePe webhook rejected: webhook credentials are not configured or Authorization is missing.');
            return response()->json(['received' => false], 401);
        }

        $expectedAuthorization = hash('sha256', $username . ':' . $password);
        if (! hash_equals($expectedAuthorization, strtolower($authorization))) {
            logger()->warning('PhonePe webhook rejected: authorization validation failed.');
            return response()->json(['received' => false], 401);
        }

        $eventData = json_decode($request->getContent(), true);
        if (! is_array($eventData) || ! is_array($eventData['payload'] ?? null)) {
            return response()->json(['received' => false], 400);
        }

        // PhonePe documentation says to use `event` (not `type`) and the root
        // payload.state field when identifying payment state.
        $event = (string) ($eventData['event'] ?? '');
        $payload = $eventData['payload'];
        if ($event === 'checkout.order.failed') {
            return response()->json(['received' => true]);
        }
        if ($event !== 'checkout.order.completed' || strtoupper((string) ($payload['state'] ?? '')) !== 'COMPLETED') {
            // Ignore events this integration does not process (e.g. refunds).
            return response()->json(['received' => true]);
        }

        $merchantOrderId = trim((string) ($payload['merchantOrderId'] ?? ''));
        $payloadAmount = filter_var($payload['amount'] ?? null, FILTER_VALIDATE_INT);
        if (! preg_match('/^CP[A-Z0-9]{24}$/', $merchantOrderId) || $payloadAmount === false || $payloadAmount < 100) {
            logger()->warning('PhonePe webhook rejected: invalid order reference or amount.');
            return response()->json(['received' => false], 400);
        }

        $stored = Cache::get('phonepe_order_' . $merchantOrderId);
        if (! is_array($stored) || ! is_array($stored['payment_data'] ?? null)) {
            // Return a retryable error so PhonePe can retry if temporary cache
            // inconsistency is the cause. The order must never be guessed from
            // webhook input alone.
            logger()->warning('PhonePe webhook could not find cached order reconciliation data.', [
                'merchant_order_id' => $merchantOrderId,
            ]);
            return response()->json(['received' => false], 503);
        }

        if ((int) ($stored['amount_paise'] ?? -1) !== (int) $payloadAmount) {
            logger()->warning('PhonePe webhook amount does not match the cached checkout amount.', [
                'merchant_order_id' => $merchantOrderId,
            ]);
            return response()->json(['received' => false], 400);
        }

        try {
            // The webhook Authorization header is validated above using the
            // SHA256(username:password) scheme configured with PhonePe. Check
            // its event, state, merchant order ID and amount against the
            // server-side checkout snapshot before processing. Avoid another
            // network call here so the webhook can be acknowledged promptly;
            // the browser callback independently verifies status via PhonePe.
            $this->completeVerifiedPayment($merchantOrderId, $stored);
            return response()->json(['received' => true]);
        } catch (Throwable $exception) {
            report($exception);
            return response()->json(['received' => false], 503);
        }
    }

    /** Mark the Botble payment complete once, only after PhonePe status was verified. */
    private function completeVerifiedPayment(string $merchantOrderId, array $stored): void
    {
        $paymentData = $stored['payment_data'] ?? [];
        if (empty($paymentData['order_id'])) {
            throw new \RuntimeException('The store order reference is missing for payment reconciliation.');
        }

        $lock = Cache::lock('phonepe_callback_lock_' . $merchantOrderId, 30);
        $lock->block(5, function () use ($merchantOrderId, $paymentData) {
            if (Cache::get('phonepe_processed_' . $merchantOrderId)) {
                return;
            }

            $existing = Payment::query()->where('charge_id', $merchantOrderId)->first();
            if ($existing && $existing->status == PaymentStatusEnum::COMPLETED) {
                Cache::put('phonepe_processed_' . $merchantOrderId, true, now()->addDay());
                return;
            }

            DB::transaction(function () use ($merchantOrderId, $paymentData) {
                do_action(PAYMENT_ACTION_PAYMENT_PROCESSED, [
                    'amount' => (float) $paymentData['amount'],
                    'currency' => 'INR',
                    'charge_id' => $merchantOrderId,
                    'order_id' => $paymentData['order_id'],
                    'customer_id' => $paymentData['customer_id'] ?? null,
                    'customer_type' => $paymentData['customer_type'] ?? null,
                    'payment_channel' => PHONEPE_PAYMENT_METHOD_NAME,
                    'status' => PaymentStatusEnum::COMPLETED,
                    'payment_fee' => (float) ($paymentData['payment_fee'] ?? 0),
                ]);
            });

            Cache::put('phonepe_processed_' . $merchantOrderId, true, now()->addDay());
        });
    }

}
