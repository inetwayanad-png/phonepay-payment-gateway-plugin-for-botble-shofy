<?php

namespace Botble\PhonePe;

use Botble\PluginManagement\Abstracts\PluginOperationAbstract;
use Botble\Setting\Facades\Setting;

class Plugin extends PluginOperationAbstract
{
    public static function remove(): void
    {
        Setting::delete([
            'payment_phonepe_name',
            'payment_phonepe_description',
            'payment_phonepe_client_id',
            'payment_phonepe_client_secret',
            'payment_phonepe_client_version',
            'payment_phonepe_environment',
            'payment_phonepe_status',
            'payment_phonepe_fee',
        ]);
    }
}
