<?php

namespace Botble\PhonePe\Providers;

use Botble\Base\Facades\Html;
use Botble\Payment\Enums\PaymentMethodEnum;
use Botble\Payment\Facades\PaymentMethods;
use Botble\Payment\Supports\PaymentFeeHelper;
use Botble\PhonePe\Forms\PhonePePaymentMethodForm;
use Botble\PhonePe\Services\Gateways\PhonePePaymentService;
use Illuminate\Http\Request;
use Illuminate\Support\ServiceProvider;
use Throwable;

class HookServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        add_filter(PAYMENT_FILTER_ADDITIONAL_PAYMENT_METHODS, [$this, 'registerMethod'], 30, 2);
        add_filter(PAYMENT_FILTER_AFTER_POST_CHECKOUT, [$this, 'checkoutWithPhonePe'], 30, 2);
        add_filter(PAYMENT_METHODS_SETTINGS_PAGE, [$this, 'addPaymentSettings'], 30);

        add_filter(BASE_FILTER_ENUM_ARRAY, function ($values, $class) {
            if ($class === PaymentMethodEnum::class) {
                $values['PHONEPE'] = PHONEPE_PAYMENT_METHOD_NAME;
            }
            return $values;
        }, 30, 2);

        add_filter(BASE_FILTER_ENUM_LABEL, function ($value, $class) {
            return $class === PaymentMethodEnum::class && $value === PHONEPE_PAYMENT_METHOD_NAME ? 'PhonePe' : $value;
        }, 30, 2);

        add_filter(BASE_FILTER_ENUM_HTML, function ($value, $class) {
            return $class === PaymentMethodEnum::class && $value === PHONEPE_PAYMENT_METHOD_NAME
                ? Html::tag('span', 'PhonePe', ['class' => 'label-success status-label'])->toHtml()
                : $value;
        }, 30, 2);

        add_filter(PAYMENT_FILTER_GET_SERVICE_CLASS, function ($serviceClass, $method) {
            return $method === PHONEPE_PAYMENT_METHOD_NAME ? PhonePePaymentService::class : $serviceClass;
        }, 30, 2);

        add_filter(PAYMENT_FILTER_PAYMENT_INFO_DETAIL, function ($html, $payment) {
            if ($payment->payment_channel !== PHONEPE_PAYMENT_METHOD_NAME || empty($payment->charge_id)) {
                return $html;
            }

            $details = app(PhonePePaymentService::class)->getPaymentDetails((string) $payment->charge_id);
            return $details ? $html . view('plugins/phonepe::detail', ['payment' => $details])->render() : $html;
        }, 30, 2);
    }

    public function addPaymentSettings(?string $settings): string
    {
        return ($settings ?? '') . PhonePePaymentMethodForm::create()->renderForm();
    }

    public function registerMethod(?string $html, array $data): string
    {
        PaymentMethods::method(PHONEPE_PAYMENT_METHOD_NAME, [
            'html' => view('plugins/phonepe::methods', $data)->render(),
        ]);

        return $html ?? '';
    }

    public function checkoutWithPhonePe(array $data, Request $request): array
    {
        if (($data['type'] ?? null) !== PHONEPE_PAYMENT_METHOD_NAME) {
            return $data;
        }

        $paymentData = apply_filters(PAYMENT_FILTER_PAYMENT_DATA, [], $request);
        if (! is_array($paymentData)) {
            $data['error'] = true;
            $data['message'] = 'Could not read the checkout order. Please refresh and try again.';
            return $data;
        }

        $paymentData['payment_fee'] = PaymentFeeHelper::calculateFee(
            PHONEPE_PAYMENT_METHOD_NAME,
            $paymentData['amount'] ?? 0
        );
        $paymentData['currency'] = $paymentData['currency'] ?? get_application_currency()->title;

        if (strtoupper((string) $paymentData['currency']) !== 'INR') {
            $data['error'] = true;
            $data['message'] = 'PhonePe supports INR payments only. Please set your store currency to INR.';
            return $data;
        }

        try {
            $service = app(PhonePePaymentService::class);
            $checkoutUrl = $service->execute($paymentData);

            if ($checkoutUrl === null || $service->getErrorMessage()) {
                $data['error'] = true;
                $data['message'] = $service->getErrorMessage() ?: 'PhonePe could not start the payment. Please try again.';
                return $data;
            }

            // Match Botble's hosted-checkout pattern: return a browser page that navigates
            // to the provider, rather than relying on a theme-specific JSON redirect key.
            echo view('plugins/phonepe::redirect', ['url' => $checkoutUrl])->render();
            exit;
        } catch (Throwable $exception) {
            report($exception);
            $data['error'] = true;
            $data['message'] = 'PhonePe payment could not be started. Please try again.';
            return $data;
        }
    }
}
