<?php

namespace Botble\PhonePe\Services\Gateways;

use Botble\Payment\Services\Traits\PaymentErrorTrait;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

class PhonePePaymentService
{
    use PaymentErrorTrait;

    private function environment(): string
    {
        return strtolower(trim((string) get_payment_setting('environment', PHONEPE_PAYMENT_METHOD_NAME))) === 'production'
            ? 'production'
            : 'sandbox';
    }

    private function apiBase(): string
    {
        return $this->environment() === 'production'
            ? 'https://api.phonepe.com/apis/pg'
            : 'https://api-preprod.phonepe.com/apis/pg-sandbox';
    }

    private function tokenUrl(): string
    {
        return $this->environment() === 'production'
            ? 'https://api.phonepe.com/apis/identity-manager/v1/oauth/token'
            : 'https://api-preprod.phonepe.com/apis/pg-sandbox/v1/oauth/token';
    }

    /**
     * Only allow PhonePe's known hosted-checkout hosts. Never redirect customers
     * to an arbitrary URL returned by an unexpected or compromised response.
     */
    private function isTrustedCheckoutUrl(string $url): bool
    {
        if (! filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }

        $parts = parse_url($url);
        if (! is_array($parts)
            || strtolower((string) ($parts['scheme'] ?? '')) !== 'https'
            || empty($parts['host'])
            || isset($parts['user'])
            || isset($parts['pass'])
            || (isset($parts['port']) && (int) $parts['port'] !== 443)) {
            return false;
        }

        $host = strtolower(rtrim((string) $parts['host'], '.'));

        // PhonePe may use different hosted-checkout subdomains across merchant
        // accounts and regions. Trust only HTTPS subdomains of PhonePe-owned
        // domains, not arbitrary URLs or lookalike domains such as phonepe.com.attacker.test.
        foreach (['.phonepe.com', '.phonepe.in'] as $trustedSuffix) {
            if (str_ends_with($host, $trustedSuffix) && strlen($host) > strlen($trustedSuffix)) {
                return true;
            }
        }

        return false;
    }

    private function accessToken(): string
    {
        $clientId = trim((string) get_payment_setting('client_id', PHONEPE_PAYMENT_METHOD_NAME));
        $clientSecret = trim((string) get_payment_setting('client_secret', PHONEPE_PAYMENT_METHOD_NAME));
        $clientVersion = trim((string) (get_payment_setting('client_version', PHONEPE_PAYMENT_METHOD_NAME) ?: '1'));

        if ($clientId === '' || $clientSecret === '') {
            throw new RuntimeException('PhonePe Client ID and Client Secret are required. Check Settings → Payment → PhonePe.');
        }

        $cacheKey = 'phonepe_access_token_' . hash('sha256', implode('|', [
            $this->environment(), $clientId, $clientVersion, $clientSecret,
        ]));

        $cached = Cache::get($cacheKey);
        if (is_string($cached) && $cached !== '') {
            return $cached;
        }

        try {
            $response = Http::asForm()
                ->acceptJson()
                ->connectTimeout(10)
                ->timeout(25)
                ->retry(2, 400, null, false)
                ->post($this->tokenUrl(), [
                    'client_id' => $clientId,
                    'client_version' => $clientVersion,
                    'client_secret' => $clientSecret,
                    'grant_type' => 'client_credentials',
                ]);
        } catch (Throwable $exception) {
            logger()->error('PhonePe OAuth request could not connect', [
                'environment' => $this->environment(),
                'endpoint' => $this->tokenUrl(),
                'exception_class' => get_class($exception),
            ]);
            throw new RuntimeException('PhonePe authentication service could not be reached. Please retry shortly.');
        }

        $json = $response->json();
        $token = is_array($json) ? (string) ($json['access_token'] ?? '') : '';

        if (! $response->successful() || $token === '') {
            logger()->error('PhonePe OAuth token request failed', [
                'environment' => $this->environment(),
                'endpoint' => $this->tokenUrl(),
                'http_status' => $response->status(),
            ]);

            if ($response->serverError()) {
                throw new RuntimeException('PhonePe returned a server error while authenticating. Check the production account/credentials and try again later.');
            }

            throw new RuntimeException('PhonePe authentication failed. Verify the Client ID, Client Secret, Client Version and selected environment.');
        }

        $expiresIn = (int) ($json['expires_in'] ?? 300);
        if (isset($json['expires_at']) && is_numeric($json['expires_at'])) {
            $expiresIn = min($expiresIn, max(60, (int) $json['expires_at'] - time()));
        }
        Cache::put($cacheKey, $token, now()->addSeconds(max(60, $expiresIn - 60)));

        return $token;
    }

    public function execute(array $data): ?string
    {
        $merchantOrderId = null;

        try {
            $currency = strtoupper(trim((string) ($data['currency'] ?? 'INR')));
            if ($currency !== 'INR') {
                throw new RuntimeException('PhonePe supports INR payments only. Set your store currency to INR.');
            }

            $checkoutToken = trim((string) ($data['checkout_token'] ?? ''));
            if ($checkoutToken === '') {
                throw new RuntimeException('The checkout session is missing. Please refresh checkout and try again.');
            }

            $amountRupees = (float) ($data['amount'] ?? 0);
            $amountPaise = (int) round($amountRupees * 100);
            if (! is_finite($amountRupees) || $amountPaise < 100) {
                throw new RuntimeException('PhonePe payment amount must be at least ₹1.00.');
            }

            $orderId = $data['order_id'] ?? null;
            if (empty($orderId)) {
                throw new RuntimeException('The store order reference is missing. Please retry checkout.');
            }

            $merchantOrderId = 'CP' . strtoupper(Str::random(24));
            // Keep the Botble checkout token out of browser history, referrer headers and access logs.
            $callbackState = Str::random(64);
            $redirectUrl = route('payments.phonepe.callback', [
                'state' => $callbackState,
                'merchantOrderId' => $merchantOrderId,
            ]);

            $paymentSnapshot = [
                'checkout_token' => $checkoutToken,
                'callback_state_hash' => hash('sha256', $callbackState),
                'amount_paise' => $amountPaise,
                'created_at' => now()->timestamp,
                'payment_data' => [
                    'amount' => $amountRupees,
                    'currency' => 'INR',
                    'order_id' => $orderId,
                    'customer_id' => $data['customer_id'] ?? null,
                    'customer_type' => $data['customer_type'] ?? null,
                    'payment_fee' => (float) ($data['payment_fee'] ?? 0),
                ],
            ];

            $orderKey = 'phonepe_order_' . $merchantOrderId;
            Cache::put($orderKey, $paymentSnapshot, now()->addHours(6));

            $metaOrderId = is_scalar($orderId) ? (string) $orderId : implode(',', array_map('strval', (array) $orderId));
            $payload = [
                'merchantOrderId' => $merchantOrderId,
                'amount' => $amountPaise,
                'expireAfter' => 1800,
                'metaInfo' => [
                    'udf1' => mb_substr($metaOrderId, 0, 256),
                ],
                'paymentFlow' => [
                    'type' => 'PG_CHECKOUT',
                    'merchantUrls' => [
                        'redirectUrl' => $redirectUrl,
                    ],
                ],
            ];

            $response = Http::withHeaders([
                'Authorization' => 'O-Bearer ' . $this->accessToken(),
            ])
                ->acceptJson()
                ->asJson()
                ->connectTimeout(10)
                ->timeout(30)
                ->post($this->apiBase() . '/checkout/v2/pay', $payload);

            $responseData = $response->json();
            $checkoutUrl = '';
            if (is_array($responseData)) {
                // Standard Checkout v2 normally returns redirectUrl at the root.
                // Accept the common nested shape defensively without trusting it
                // until the URL passes the PhonePe domain validation below.
                $checkoutUrl = (string) ($responseData['redirectUrl']
                    ?? $responseData['data']['redirectUrl']
                    ?? $responseData['redirect_url']
                    ?? $responseData['data']['redirect_url']
                    ?? '');
            }

            if (! $response->successful() || ! $this->isTrustedCheckoutUrl($checkoutUrl)) {
                Cache::forget($orderKey);
                $redirectHost = '';
                if ($checkoutUrl !== '') {
                    $urlParts = parse_url($checkoutUrl);
                    $redirectHost = is_array($urlParts) ? strtolower((string) ($urlParts['host'] ?? '')) : '';
                }
                logger()->error('PhonePe payment creation response was not accepted', [
                    'environment' => $this->environment(),
                    'endpoint' => $this->apiBase() . '/checkout/v2/pay',
                    'http_status' => $response->status(),
                    'merchant_order_id' => $merchantOrderId,
                    'response_keys' => is_array($responseData) ? array_values(array_intersect(array_keys($responseData), ['redirectUrl', 'redirect_url', 'data', 'orderId', 'state', 'code', 'message', 'success'])) : [],
                    'api_code' => is_array($responseData) ? (string) ($responseData['code'] ?? '') : '',
                    'api_message' => is_array($responseData) ? mb_substr((string) ($responseData['message'] ?? ''), 0, 180) : '',
                    'redirect_host' => $redirectHost,
                    'trusted_redirect_url' => $this->isTrustedCheckoutUrl($checkoutUrl),
                ]);
                throw new RuntimeException('PhonePe returned a checkout response that could not be safely validated. Check the Laravel log for the response code and redirect host.');
            }

            return $checkoutUrl;
        } catch (Throwable $exception) {
            if ($merchantOrderId !== null) {
                Cache::forget('phonepe_order_' . $merchantOrderId);
            }
            report($exception);
            $this->setErrorMessage($exception instanceof RuntimeException
                ? $exception->getMessage()
                : 'PhonePe payment could not be started. Please try again.');

            return null;
        }
    }

    public function verifyOrder(string $merchantOrderId): array
    {
        if ($merchantOrderId === '' || ! preg_match('/^[A-Za-z0-9_-]{1,63}$/', $merchantOrderId)) {
            throw new RuntimeException('Invalid PhonePe merchant order reference.');
        }

        $response = Http::withHeaders([
            'Authorization' => 'O-Bearer ' . $this->accessToken(),
        ])
            ->acceptJson()
            ->connectTimeout(10)
            ->timeout(25)
            ->get($this->apiBase() . '/checkout/v2/order/' . rawurlencode($merchantOrderId) . '/status');

        if (! $response->successful() || ! is_array($response->json())) {
            logger()->error('PhonePe order status verification failed', [
                'http_status' => $response->status(),
                'merchant_order_id' => $merchantOrderId,
                'environment' => $this->environment(),
            ]);
            throw new RuntimeException('PhonePe could not confirm the payment status.');
        }

        return (array) $response->json();
    }

    public function getPaymentDetails(string $merchantOrderId): ?array
    {
        try {
            return $this->verifyOrder($merchantOrderId);
        } catch (Throwable $exception) {
            report($exception);
            return null;
        }
    }

    public function supportedCurrencyCodes(): array
    {
        return ['INR'];
    }
}
